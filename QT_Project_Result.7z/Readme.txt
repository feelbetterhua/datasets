Ux is the data of sailing state, U0 is the data of static state.
Saved in MATLAB files, X and Y are the training input and output, x and y is the test input and output.
Trained models can open with MATLAB Regression Toolbox.